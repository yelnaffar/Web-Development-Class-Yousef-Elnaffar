window.onload = setup
function setup(){
   let buttons = document.querySelectorAll(".the"); // This button selects all the iteams
  
    buttons.forEach(btn=>{})
   for(let i=0; i<buttons.length; i++){
     buttons[i].addEventListener("click", addItem);  // Detials to buttons
   }
 }
 
 
 let addedItems = []; // tracking iteams added to wishlist
 let wishList = [];  // real wishlist
  function addItem(e){
     let item = "class" +e.target.id;
       // pulling out the the identifying id
    
   
  
  if (!wishList.includes(item)){ // to see where thee iteam is 
     wishList.push(item);
       var aside = document.querySelector("aside"); // check where the itemas will be 
       var content = document.getElementById(item).innerHTML; // what is going to be displayed
       var asidecontent = aside.innerHTML; // what competencies are going to be 
       aside.innerHTML = content + asidecontent ; // check what the content is going to be 
  }
 
 
   else{
     alert("CLassses in Favorite Courses.");  // let user know when doing it twice 
    
}
 }
